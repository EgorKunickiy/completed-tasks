This is a simple example package.
https://github.com/EgorKunickiy/completed-tasks